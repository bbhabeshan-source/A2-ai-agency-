import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { parse } from 'jsonc-parser';
import { afterEach, describe, expect, it } from 'vitest';
import { applyGeneratedFile, applyGeneratedFiles, renderFile } from './config-files.js';

const temporary: string[] = [];

afterEach(() => {
  for (const directory of temporary.splice(0)) {
    fs.rmSync(directory, { recursive: true, force: true });
  }
});

describe('safe config writes', () => {
  it('writes a fresh env file without a leading blank line', () => {
    const rendered = renderFile({ path: '/unused', format: 'env', content: 'FREELLMAPI_API_KEY=k\n' }, '');
    expect(rendered).toBe('FREELLMAPI_API_KEY=k\n');
    expect(renderFile({ path: '/unused', format: 'env', content: 'FREELLMAPI_API_KEY=k\n' }, rendered)).toBe(rendered);
  });

  it('appends a new env key without leaving a blank line before it', () => {
    const merged = renderFile(
      { path: '/unused/.env', format: 'env', content: 'FREELLMAPI_API_KEY=k\n' },
      'DEEPSEEK_API_KEY=sk-keep\n',
    );
    expect(merged).toBe('DEEPSEEK_API_KEY=sk-keep\nFREELLMAPI_API_KEY=k\n');
  });

  it('merges keyed JSON arrays per owner instead of replacing them (ZCode)', () => {
    const existing = JSON.stringify({
      schemaVersion: 1,
      config: {
        providerConfigRules: { providerRules: [
          { providerId: 'local', providerName: 'Mine' },
          { providerId: 'freellmapi', providerName: 'Old' },
        ] },
        modelConfigRules: {
          providerModelRules: [{ providerId: 'local', modelId: 'm' }, { providerId: 'freellmapi', modelId: 'gone' }],
          manualProviderModelRules: [{ providerId: 'freellmapi', modelId: 'fast' }, { providerId: 'local', modelId: 'x' }],
        },
        providerOrder: ['local', 'freellmapi'],
      },
    }, null, 2);
    const file = {
      path: '/unused/provider_config.json',
      format: 'json' as const,
      arrays: {
        'config.providerConfigRules.providerRules': { ownedBy: { providerId: 'freellmapi' } },
        'config.modelConfigRules.providerModelRules': { ownedBy: { providerId: 'freellmapi' } },
        'config.modelConfigRules.manualProviderModelRules': { ownedBy: { providerId: 'freellmapi' } },
        'config.providerOrder': { union: true as const },
      },
      value: {
        config: {
          providerConfigRules: { providerRules: [{ providerId: 'freellmapi', providerName: 'FreeLLMAPI' }] },
          modelConfigRules: {
            providerModelRules: [{ providerId: 'freellmapi', modelId: 'fast' }],
            manualProviderModelRules: [],
          },
          providerOrder: ['freellmapi'],
        },
      },
    };
    const once = renderFile(file, existing);
    const merged = parse(once).config;
    expect(merged.providerConfigRules.providerRules).toEqual([
      { providerId: 'local', providerName: 'Mine' },
      { providerId: 'freellmapi', providerName: 'FreeLLMAPI' },
    ]);
    expect(merged.modelConfigRules.providerModelRules).toEqual([
      { providerId: 'local', modelId: 'm' },
      { providerId: 'freellmapi', modelId: 'fast' },
    ]);
    expect(merged.modelConfigRules.manualProviderModelRules).toEqual([{ providerId: 'local', modelId: 'x' }]);
    expect(merged.providerOrder).toEqual(['local', 'freellmapi']);
    expect(renderFile(file, once)).toBe(once);
  });

  it('renders a fresh Continue config idempotently', () => {
    const generated = [
      '# freellmapi:start',
      'name: FreeLLMAPI',
      'version: 1.0.0',
      'schema: v1',
      'models:',
      '  - name: FreeLLMAPI',
      '    provider: openai',
      '    model: coder',
      '# freellmapi:end',
      '',
    ].join('\n');
    const first = renderFile({
      path: '/unused',
      format: 'yaml',
      content: generated,
    });
    const second = renderFile({
      path: '/unused',
      format: 'yaml',
      content: generated,
    }, first);
    expect(second).toBe(first);
    expect(first).not.toContain('freellmapi:start');
    expect(first.match(/^models:$/gm)).toHaveLength(1);
  });

  it('deep-merges JSONC and retains inline and leading comments', () => {
    const existing = [
      '// user configuration',
      '{',
      '  // keep the chosen theme',
      '  "theme": "dark",',
      '  "provider": {',
      '    /* keep the unrelated provider */',
      '    "other": true,',
      '  },',
      '}',
      '',
    ].join('\n');
    const rendered = renderFile({
      path: '/unused',
      format: 'json',
      value: { provider: { freellmapi: true } },
    }, existing);
    expect(rendered).toContain('// user configuration');
    expect(rendered).toContain('// keep the chosen theme');
    expect(rendered).toContain('/* keep the unrelated provider */');
    expect(parse(rendered)).toEqual({
      theme: 'dark',
      provider: { other: true, freellmapi: true },
    });
  });

  it('merges Continue into an existing config without replacing other models', () => {
    const existing = [
      '# personal config',
      'name: Personal',
      'version: 2.0.0',
      'schema: v1',
      'models:',
      '  - name: Existing',
      '    provider: ollama',
      '    model: qwen',
      'rules:',
      '  - Keep this rule',
      '',
    ].join('\n');
    const generated = [
      '# freellmapi:start',
      'name: FreeLLMAPI',
      'version: 1.0.0',
      'schema: v1',
      'models:',
      '  - name: FreeLLMAPI',
      '    provider: openai',
      '    model: coder',
      '# freellmapi:end',
      '',
    ].join('\n');
    const first = renderFile({
      path: '/unused',
      format: 'yaml',
      content: generated,
    }, existing);
    const second = renderFile({
      path: '/unused',
      format: 'yaml',
      content: generated,
    }, first);
    expect(second).toBe(first);
    expect(first).toContain('# personal config');
    expect(first).toContain('name: Personal');
    expect(first).toContain('  - name: Existing');
    expect(first).toContain('  - name: FreeLLMAPI');
    expect(first).toContain('rules:\n  - Keep this rule');
    expect(first.match(/^models:$/gm)).toHaveLength(1);
  });

  it('upgrades a previously marked Continue block without leaving duplicate keys', () => {
    const existing = [
      'name: Personal',
      'version: 2.0.0',
      'schema: v1',
      'models:',
      '  - name: Existing',
      '    provider: ollama',
      '    model: qwen',
      '# freellmapi:start',
      'models:',
      '  - name: FreeLLMAPI',
      '    provider: openai',
      '    model: old',
      '# freellmapi:end',
      '',
    ].join('\n');
    const generated = [
      '# freellmapi:start',
      'name: FreeLLMAPI',
      'version: 1.0.0',
      'schema: v1',
      'models:',
      '  - name: FreeLLMAPI',
      '    provider: openai',
      '    model: current',
      '# freellmapi:end',
      '',
    ].join('\n');
    const rendered = renderFile({
      path: '/unused',
      format: 'yaml',
      content: generated,
    }, existing);
    expect(rendered.match(/^name:/gm)).toHaveLength(1);
    expect(rendered.match(/^version:/gm)).toHaveLength(1);
    expect(rendered.match(/^schema:/gm)).toHaveLength(1);
    expect(rendered.match(/^models:/gm)).toHaveLength(1);
    expect(rendered).toContain('  - name: Existing');
    expect(rendered).toContain('    model: current');
    expect(rendered).not.toContain('    model: old');
  });

  it('replaces generated YAML scalar keys without creating duplicates', () => {
    const existing = '# user config\nGOOSE_PROVIDER: old\nGOOSE_MODEL: old\nkeep: true\n';
    const generated = [
      '# freellmapi:start',
      'GOOSE_PROVIDER: freellmapi',
      'GOOSE_MODEL: coder',
      '# freellmapi:end',
      '',
    ].join('\n');
    const first = renderFile({
      path: '/unused',
      format: 'yaml',
      content: generated,
    }, existing);
    const second = renderFile({
      path: '/unused',
      format: 'yaml',
      content: generated,
    }, first);
    expect(second).toBe(first);
    expect(first).toContain('# user config');
    expect(first).toContain('keep: true');
    expect(first.match(/^GOOSE_PROVIDER:/gm)).toHaveLength(1);
    expect(first.match(/^GOOSE_MODEL:/gm)).toHaveLength(1);
  });

  it('deep-merges structured YAML and retains sibling routes and comments', () => {
    // DeepSeek Harness keeps every provider under one `llm-pi-ai.providers`
    // dict. The marked-block YAML merge removes whole top-level keys it
    // re-emits, which here would delete the user's other providers; the
    // structured merge must touch only the path it sets.
    const existing = [
      '# my settings',
      'llm-pi-ai:',
      '  providers:',
      '    anthropic:',
      '      # keep me',
      '      apiKeyEnv: ANTHROPIC_API_KEY',
      '    freellmapi:',
      '      baseURL: http://old:1/v1',
      '      models:',
      '        - id: stale',
      'agent-default-model:',
      '  provider: anthropic',
      '  model: claude-sonnet-4-5',
      '  reasoningEffort: high',
      'other: { a: 1 }',
      '',
    ].join('\n');
    const file = {
      path: '/tmp/settings.yaml',
      format: 'yaml' as const,
      value: {
        'llm-pi-ai': {
          providers: {
            freellmapi: {
              baseURL: 'http://localhost:3001/v1',
              models: [{ id: 'auto' }],
            },
          },
        },
        'agent-default-model': {
          provider: 'freellmapi',
          model: 'auto',
          reasoningEffort: undefined,
        },
      },
    };
    const once = renderFile(file, existing);
    expect(once).toContain('# my settings');
    expect(once).toContain('# keep me');
    expect(once).toContain('apiKeyEnv: ANTHROPIC_API_KEY');
    expect(once).toContain('baseURL: http://localhost:3001/v1');
    expect(once).not.toContain('http://old:1/v1');
    expect(once).not.toContain('stale');
    expect(once).toContain('provider: freellmapi');
    expect(once).not.toContain('reasoningEffort');
    expect(once).toContain('other: { a: 1 }');
    expect(renderFile(file, once)).toBe(once);
  });

  it('renders structured YAML from an empty or comment-only document', () => {
    const file = {
      path: '/tmp/settings.yaml',
      format: 'yaml' as const,
      value: { a: { b: [1, 2] }, c: undefined },
    };
    expect(renderFile(file, '')).toBe('a:\n  b:\n    - 1\n    - 2\n');
    expect(renderFile(file, '# only a comment\n')).toContain('a:\n  b:\n    - 1\n    - 2\n');
  });

  it('refuses to merge structured YAML into a document it cannot parse', () => {
    const file = {
      path: '/tmp/settings.yaml',
      format: 'yaml' as const,
      value: { a: 1 },
    };
    expect(() => renderFile(file, 'a: [1, 2\n')).toThrow(/cannot be parsed/);
    expect(() => renderFile(file, '- just\n- a list\n')).toThrow(/not a mapping/);
  });

  it('replaces conflicting Codex TOML settings and retains unrelated tables', () => {
    const existing = [
      '# personal config',
      'model = "old"',
      'model_provider = "old"',
      '',
      '[model_providers.freellmapi]',
      'name = "Old"',
      'base_url = "https://old.invalid/v1"',
      '',
      '[mcp_servers.personal]',
      'command = "keep-me"',
      '',
    ].join('\n');
    const generated = [
      '# freellmapi:start',
      'model = "coder"',
      'model_provider = "freellmapi"',
      '',
      '[model_providers.freellmapi]',
      'name = "FreeLLMAPI"',
      'base_url = "http://localhost:3000/v1"',
      '# freellmapi:end',
      '',
    ].join('\n');
    const first = renderFile({
      path: '/unused',
      format: 'toml',
      content: generated,
    }, existing);
    const second = renderFile({
      path: '/unused',
      format: 'toml',
      content: generated,
    }, first);
    expect(second).toBe(first);
    expect(first).toContain('# personal config');
    expect(first).toContain('[mcp_servers.personal]\ncommand = "keep-me"');
    expect(first.match(/^model =/gm)).toHaveLength(1);
    expect(first.match(/^\[model_providers\.freellmapi\]$/gm)).toHaveLength(1);
  });

  it('keeps generated root TOML keys in the root region when the file ends in a table', () => {
    const existing = [
      '# personal config',
      'sandbox_mode = "workspace-write"',
      '',
      '[mcp_servers.personal]',
      'command = "keep-me"',
      'args = ["--serve"]',
      '',
    ].join('\n');
    const generated = [
      '# freellmapi:start',
      'model = "coder"',
      'model_provider = "freellmapi"',
      '',
      '[model_providers.freellmapi]',
      'name = "FreeLLMAPI"',
      'base_url = "http://localhost:3000/v1"',
      '# freellmapi:end',
      '',
    ].join('\n');
    const first = renderFile({
      path: '/unused',
      format: 'toml',
      content: generated,
    }, existing);
    const second = renderFile({
      path: '/unused',
      format: 'toml',
      content: generated,
    }, first);
    expect(second).toBe(first);

    // Root-level keys must appear BEFORE the first table header, otherwise
    // TOML assigns them to that table.
    const lines = first.split('\n');
    const firstHeader = lines.findIndex(line => /^\[[^\]]+\]$/.test(line));
    const modelLine = lines.findIndex(line => line === 'model = "coder"');
    const providerLine = lines.findIndex(line => line === 'model_provider = "freellmapi"');
    expect(firstHeader).toBeGreaterThan(-1);
    expect(modelLine).toBeGreaterThan(-1);
    expect(modelLine).toBeLessThan(firstHeader);
    expect(providerLine).toBeGreaterThan(-1);
    expect(providerLine).toBeLessThan(firstHeader);
    expect(first).toContain('sandbox_mode = "workspace-write"');
    expect(first).toContain('[mcp_servers.personal]\ncommand = "keep-me"\nargs = ["--serve"]');
    expect(first).toContain('[model_providers.freellmapi]');
  });

  it('only strips root TOML keys that the generated root region sets', () => {
    const existing = [
      'name = "my personal codex"',
      'model = "old"',
      '',
      '[mcp_servers.personal]',
      'command = "keep-me"',
      '',
    ].join('\n');
    const generated = [
      '# freellmapi:start',
      'model = "coder"',
      '',
      '[model_providers.freellmapi]',
      'name = "FreeLLMAPI"',
      '# freellmapi:end',
      '',
    ].join('\n');
    const first = renderFile({
      path: '/unused',
      format: 'toml',
      content: generated,
    }, existing);
    // The generated TABLE sets `name`, but the user's ROOT-level `name` is a
    // different key and must survive.
    expect(first).toContain('name = "my personal codex"');
    expect(first.match(/^model =/gm)).toHaveLength(1);
    expect(first).toContain('model = "coder"');
  });

  it('does not write any file when a later file in the batch fails to merge', () => {
    const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'freellmapi-cli-'));
    temporary.push(directory);
    const good = path.join(directory, 'good.json');
    const bad = path.join(directory, 'bad.json');
    fs.writeFileSync(bad, '{ this is not json');
    expect(() => applyGeneratedFiles([
      { path: good, format: 'json', value: { enabled: true } },
      { path: bad, format: 'json', value: { enabled: true } },
    ], false)).toThrow('cannot be parsed safely');
    expect(fs.existsSync(good)).toBe(false);
    expect(fs.readFileSync(bad, 'utf8')).toBe('{ this is not json');
  });

  it('merges an AtomCode config: root key above existing tables, other providers kept', () => {
    // A user with a DeepSeek provider already configured runs setup-atomcode:
    // `default_provider` must land in the root region (a key appended after
    // `[providers.deepseek]` would become that table's key), the deepseek
    // table must survive, and a stale `[providers.freellmapi]` is replaced.
    const existing = [
      'default_provider = "deepseek"',
      'auto_update = true',
      '',
      '[providers.deepseek]',
      'type = "openai"',
      'api_key = "sk-keep"',
      'model = "deepseek-chat"',
      '',
      '[providers.freellmapi]',
      'type = "openai"',
      'model = "stale-model"',
      '',
    ].join('\n');
    const generated = [
      'default_provider = "freellmapi"',
      '',
      '[providers.freellmapi]',
      'type = "openai"',
      'base_url = "http://localhost:3000/v1"',
      'api_key = "freellmapi-test-key"',
      'model = "fast-coder"',
      'context_window = 131072',
    ].join('\n');
    const merged = renderFile({ path: '/unused', format: 'toml', content: generated }, existing);
    const lines = merged.split('\n');
    const firstTable = lines.findIndex(line => line.startsWith('['));
    expect(lines.slice(0, firstTable)).toContain('default_provider = "freellmapi"');
    expect(lines.slice(0, firstTable)).toContain('auto_update = true');
    expect(merged.match(/^default_provider =/gm)).toHaveLength(1);
    expect(merged).toContain('[providers.deepseek]\ntype = "openai"\napi_key = "sk-keep"');
    expect(merged.match(/^\[providers\.freellmapi\]$/gm)).toHaveLength(1);
    expect(merged).not.toContain('stale-model');
    expect(merged).toContain('context_window = 131072');
    expect(renderFile({ path: '/unused', format: 'toml', content: generated }, merged)).toBe(merged);
  });

  it('merges a Reasonix config: replaces only the [[providers]] entry with the same name', () => {
    // Reasonix keeps every endpoint as a `[[providers]]` array entry. A rerun
    // must swap the stale freellmapi entry (and its sub-table) for the new one
    // and leave the deepseek entry, the [desktop] table and root keys alone.
    const existing = [
      'config_version = 1',
      'default_model = "deepseek/deepseek-flash"',
      '',
      '[desktop]',
      'provider_access = ["deepseek"]',
      '',
      '[[providers]]',
      'name        = "deepseek"',
      'kind        = "openai"',
      'api_key_env = "DEEPSEEK_API_KEY"',
      '',
      '[[providers]]',
      "name = 'freellmapi'",
      'base_url = "http://stale:9/v1"',
      '',
      '[providers.model_overrides]',
      'stale = { context_window = 1 }',
      '',
      '[[plugins]]',
      'name = "freellmapi"',
      'command = "keep-me"',
      '',
    ].join('\n');
    const generated = [
      'default_model = "freellmapi/auto"',
      '',
      '[[providers]]',
      'name = "freellmapi"',
      'kind = "openai"',
      'base_url = "http://localhost:3001/v1"',
      'models = ["auto"]',
    ].join('\n');
    const merged = renderFile({ path: '/unused', format: 'toml', content: generated }, existing);
    const lines = merged.split('\n');
    const firstTable = lines.findIndex(line => line.startsWith('['));
    expect(lines.slice(0, firstTable)).toContain('default_model = "freellmapi/auto"');
    expect(lines.slice(0, firstTable)).toContain('config_version = 1');
    expect(merged.match(/^default_model =/gm)).toHaveLength(1);
    expect(merged).toContain('[desktop]\nprovider_access = ["deepseek"]');
    expect(merged).toContain('name        = "deepseek"\nkind        = "openai"');
    expect(merged).toContain('[[plugins]]\nname = "freellmapi"\ncommand = "keep-me"');
    expect(merged.match(/^\[\[providers\]\]$/gm)).toHaveLength(2);
    expect(merged).not.toContain('stale');
    expect(merged).toContain('base_url = "http://localhost:3001/v1"');
    expect(renderFile({ path: '/unused', format: 'toml', content: generated }, merged)).toBe(merged);
  });

  it('creates a timestamped backup before replacing a real file', () => {
    const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'freellmapi-cli-'));
    temporary.push(directory);
    const target = path.join(directory, 'config.toml');
    fs.writeFileSync(target, 'user_setting = true\n');
    const result = applyGeneratedFile({
      path: target,
      format: 'toml',
      content: '# freellmapi:start\nmodel = "auto"\n# freellmapi:end\n',
    }, false);
    expect(result.backupPath).toBeTruthy();
    expect(fs.readFileSync(result.backupPath!, 'utf8')).toBe('user_setting = true\n');
    expect(fs.readFileSync(target, 'utf8')).toContain('user_setting = true');
    expect(fs.readFileSync(target, 'utf8')).toContain('model = "auto"');
  });

  it('does not write in dry-run mode', () => {
    const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'freellmapi-cli-'));
    temporary.push(directory);
    const target = path.join(directory, 'new.json');
    const result = applyGeneratedFile({
      path: target,
      format: 'json',
      value: { enabled: true },
    }, true);
    expect(result.changed).toBe(true);
    expect(fs.existsSync(target)).toBe(false);
  });
});
